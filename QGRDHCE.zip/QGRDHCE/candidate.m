function [ Candidate_Psi_U,maxValue_Psi_U,Candidate_Pci_U,minValue_Pci_U, Candidate_Psi_D,maxValue_Psi_D,Candidate_Pci_D,minValue_Pci_D, Candidate_Psj_L,maxValue_Psj_L,Candidate_Pcj_L,minValue_Pcj_L, Candidate_Psj_R,maxValue_Psj_R,Candidate_Pcj_R,minValue_Pcj_R ] = candidate(image_mat, HistMatrix)
        S_x_U = zeros(1, 2);
        S_x_U(1) = 3; S_x_U(2) = 256;
        [ Candidate_Psi_U, maxValue_Psi_U ] = get_PsiU_candidate(HistMatrix, S_x_U);
        [Candidate_Pci_U, minValue_Pci_U] = find_UHS_Candidate(HistMatrix, Candidate_Psi_U);
    
        S_x_D = zeros(1, 2);
        S_x_D(1) = 1; S_x_D(2) = 254;
        [ Candidate_Psi_D, maxValue_Psi_D ] = get_PsiD_candidate(HistMatrix, S_x_D);
        [Candidate_Pci_D, minValue_Pci_D] = find_DHS_Candidate(HistMatrix, Candidate_Psi_D);
    
        S_y_L = zeros(1, 2);
        S_y_L(1) = 3; S_y_L(2) = 256;
        [ Candidate_Psj_L, maxValue_Psj_L ] = get_PsjL_candidate(HistMatrix, S_y_L);
        [Candidate_Pcj_L, minValue_Pcj_L] = find_LHS_Candidate(HistMatrix, Candidate_Psj_L);

        S_y_R = zeros(1, 2);
        S_y_R(1) = 1; S_y_R(2) = 254;
        [ Candidate_Psj_R, maxValue_Psj_R ] = get_PsjR_candidate(HistMatrix, S_y_R);
        [Candidate_Pcj_R, minValue_Pcj_R] = find_RHS_Candidate(HistMatrix, Candidate_Psj_R);
end