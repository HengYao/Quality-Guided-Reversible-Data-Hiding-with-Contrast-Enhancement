function [Psi,Pci,Psj,Pcj,i_j,H_Ps,LM_size] = peaktest(Candidate_Psi_U,Candidate_Pci_U,maxValue_Psi_U, minValue_Pci_U,Candidate_Psi_D,Candidate_Pci_D,maxValue_Psi_D,minValue_Pci_D, Candidate_Psj_L,Candidate_Pcj_L,maxValue_Psj_L, minValue_Pcj_L, Candidate_Psj_R,Candidate_Pcj_R,maxValue_Psj_R,minValue_Pcj_R,original_image,image)
    global w;
    global time;
    global delta;
    Psc_list_U = zeros(5,4);
    Psc_list_D = zeros(5,4);
    Psc_list_L = zeros(5,4);
    Psc_list_R = zeros(5,4);
    for i = 1:5
        Psc_list_U(i,1) = Candidate_Psi_U(i);
        Psc_list_U(i,2) = maxValue_Psi_U(i);
        Psc_list_U(i,3) = Candidate_Pci_U(i);
        Psc_list_U(i,4) = minValue_Pci_U(i);
    end
    for i = 1:5
        Psc_list_D(i,1) = Candidate_Psi_D(i);
        Psc_list_D(i,2) = maxValue_Psi_D(i);
        Psc_list_D(i,3) = Candidate_Pci_D(i);
        Psc_list_D(i,4) = minValue_Pci_D(i);
    end
    for i = 1:5
        Psc_list_L(i,1) = Candidate_Psj_L(i);
        Psc_list_L(i,2) = maxValue_Psj_L(i);
        Psc_list_L(i,3) = Candidate_Pcj_L(i);
        Psc_list_L(i,4) = minValue_Pcj_L(i);
    end
    for i = 1:5
        Psc_list_R(i,1) = Candidate_Psj_R(i);
        Psc_list_R(i,2) = maxValue_Psj_R(i);
        Psc_list_R(i,3) = Candidate_Pcj_R(i);
        Psc_list_R(i,4) = minValue_Pcj_R(i);
    end
  
    record_score_U = zeros(1,5);
    record_all1 = zeros(5,6);
    a1 = w(1);   a2 = w(2);   a3 = w(3);   a4 = w(4);   a5 = w(5);
    for i = 1:5
        original_img = original_image; 
        [brisque,vif,rce,rmbe,ssim] = test_processing(image, Psc_list_U(i,1),0,Psc_list_U(i,3),0,0,1,0,original_img,Psc_list_U(i,2));      
        record_all1(i,:) = [brisque,vif,rce,rmbe,ssim];       
    end
    record_score_D = zeros(1,5);
    record_all2 = zeros(5,6);
    for i = 1:5         
        original_img = original_image;
        [brisque,vif,rce,rmbe,ssim] = test_processing(image, Psc_list_D(i,1),0,Psc_list_D(i,3),0,0,-1,0,original_img,Psc_list_D(i,2));      
        record_all2(i,:) = [brisque,vif,rce,rmbe,ssim];     
    end
    
    record_score_L = zeros(1,5);
    record_all3 = zeros(5,6);
    for i = 1:5   
        original_img = original_image;
        [brisque,vif,rce,rmbe,ssim] = test_processing(image,0,Psc_list_L(i,1),0,Psc_list_L(i,3),-1,0,1,original_img,Psc_list_L(i,2));       
        record_all3(i,:) = [score,brisque,vif,rce,rmbe,ssim];    
    end
    
    record_score_R = zeros(1,5);
    record_all4 = zeros(5,6);
    for i = 1:5   
        original_img = original_image;
        [brisque,vif,rce,rmbe,ssim] = test_processing(image,0, Psc_list_R(i,1),0,Psc_list_R(i,3),1,0,1,original_img,Psc_list_R(i,2));      	
        record_all4(i,:) = [score,brisque,vif,rce,rmbe,ssim];        
    end
    
    max_val_D = max(record_score_D);
    max_val_U = max(record_score_U);
    max_val_L = max(record_score_L);
    max_val_R = max(record_score_R);
    max_ = [max_val_D,max_val_U,max_val_L,max_val_R];
    [~,index] = max(max_);
    if index == 1
        max_idx_D = find(record_score_D == max_val_D);
        for i = 1:5
            if record_all2(i,1) == max_val_D
                temp_record1 = [record_all2(i,2) record_all2(i,3) record_all2(i,4) record_all2(i,5) record_all2(i,6)]; 
                w = Optimization(record_all2(i,2),record_all2(i,3),record_all2(i,4),record_all2(i,5),record_all2(i,6),w,delta);
                break;
            end
        end
        Psi = Psc_list_D(max_idx_D,1);
        Pci = Psc_list_D(max_idx_D,3);
        H_Ps = Psc_list_D(max_idx_D,2);
        LM_size = Psc_list_D(max_idx_D,4);
        Psj = 0;
        Pcj = 0;
        i_j = 0;
    elseif index == 2
        max_idx_U = find(record_score_U == max_val_U);
         for i = 1:5
            if record_all1(i,1) == max_val_U
                temp_record2 = [record_all1(i,2) record_all1(i,3) record_all1(i,4) record_all1(i,5) record_all1(i,6)]; 
                w = Optimization(record_all1(i,2),record_all1(i,3),record_all1(i,4),record_all1(i,5),record_all1(i,6),w ,delta);
                break;
            end
        end
        Psi = Psc_list_U(max_idx_U,1);
        Pci = Psc_list_U(max_idx_U,3);
        H_Ps = Psc_list_U(max_idx_U,2);
        LM_size = Psc_list_U(max_idx_U,4);
        Psj = 0;
        Pcj = 0;
        i_j = 0;
    elseif index == 3 
        max_idx_L = find(record_score_L == max_val_L);
      	for i = 1:5
            if record_all3(i,1) == max_val_L
                temp_record3 = [record_all3(i,2) record_all3(i,3) record_all3(i,4) record_all3(i,5) record_all3(i,6)]; 
                w = Optimization(record_all3(i,2),record_all3(i,3),record_all3(i,4),record_all3(i,5),record_all3(i,6),w ,delta);
                break;
            end
        end
        Psj = Psc_list_L(max_idx_L,1);  
        Pcj = Psc_list_L(max_idx_L,3);
        H_Ps = Psc_list_L(max_idx_L,2);
        LM_size = Psc_list_L(max_idx_L,4);
        Psi = 0;
        Pci = 0;
        i_j = 1;
    else 
       max_idx_R = find(record_score_R == max_val_R);
      	for i = 1:5
            if record_all4(i,1) == max_val_R
                temp_record4 = [record_all4(i,2) record_all4(i,3) record_all4(i,4) record_all4(i,5) record_all4(i,6)]; 
                w = Optimization(record_all4(i,2),record_all4(i,3),record_all4(i,4),record_all4(i,5),record_all4(i,6),w ,delta);
                break;
            end
        end
        Psj = Psc_list_R(max_idx_R,1);
        Pcj = Psc_list_R(max_idx_R,3);
        H_Ps = Psc_list_R(max_idx_R,2);
        LM_size = Psc_list_R(max_idx_R,4);
        Psi = 0;
        Pci = 0;
        i_j = 1;
    end
end