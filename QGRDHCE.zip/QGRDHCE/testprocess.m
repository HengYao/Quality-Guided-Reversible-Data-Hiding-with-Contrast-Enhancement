function [brisque,vif,rce,rmbe,ssim] = testprocess(image_mat, Ps_i, Ps_j, Pc_i, Pc_j, D_r, D_c, i_j ,original_image,H_Ps)
   image_size = size(image_mat);  
   LM = [];
   if i_j == 0
       for i = 1 : image_size(1)
           for j = 1 : 2 : image_size(2)
               if image_mat(i, j) == Pc_i-1 || image_mat(i, j) == Pc_i+D_c-1
                   if image_mat(i, j) == Pc_i-1
                       LM = [LM, 0];
                   else
                       LM = [LM, 1];
                   end
               end
           end
       end
   else
       for i = 1 : image_size(1)
           for j = 1 : 2 : image_size(2)
               if image_mat(i, j+1) == Pc_j-1 || image_mat(i, j+1) == Pc_j-D_r-1
                   if image_mat(i, j+1) == Pc_j-1
                       LM = [LM, 0];
                   else
                       LM = [LM, 1];
                   end
               end
           end
       end
   end
   temp_p = 1;       
   sum = 0;
   if i_j == 0
       for j = 1 : 2 : 17
           if image_mat(1, j) == Ps_i - 1
               sum = sum + 1;
           end
       end
   else
       for j = 1 : 2 : 17
           if image_mat(1, j+1) == Ps_j - 1
               sum = sum + 1;
           end
       end
   end

   lack_length = H_Ps - length(LM) - 17;
    
   if i_j == 0
       message=[LM , de2bi(Ps_i-1,8), de2bi(Pc_i-1,8), i_j, actual_payload'];
   else
       message=[LM , de2bi(Ps_j-1,8), de2bi(Pc_j-1,8), i_j, actual_payload'];
   end
        
    if i_j == 0
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if image_mat(i, j) == Pc_i+D_c-1
                    image_mat(i, j) = image_mat(i, j) - D_c;
                end
            end
        end
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if D_c == 1
                    if image_mat(i, j) > Pc_i-1 && image_mat(i, j) < Ps_i-1
                        image_mat(i, j) = image_mat(i, j) - D_c;
                    end
                else
                    if image_mat(i, j) < Pc_i-1 && image_mat(i, j) > Ps_i-1
                        image_mat(i, j) = image_mat(i, j) - D_c;
                    end
                end
            end
        end
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if image_mat(i,j) == Ps_i - 1
                    if message(temp) == 0
                        temp = temp + 1;
                    else 
                        image_mat(i, j) = image_mat(i, j) - D_c;
                        temp = temp + 1;
                    end
                end
            end
        end   
    else
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if image_mat(i, j+1) == Pc_j-D_r-1
                    image_mat(i, j+1) = image_mat(i, j+1) + D_r;
                end
            end
        end
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if D_r == 1
                    if image_mat(i, j+1) > Ps_j-1 && image_mat(i, j+1) < Pc_j-1
                        image_mat(i, j+1) = image_mat(i, j+1) + D_r;
                    end
                else
                    if image_mat(i, j+1) < Ps_j-1 && image_mat(i, j+1) > Pc_j-1
                        image_mat(i, j+1) = image_mat(i, j+1) + D_r;
                    end
                end
            end
        end
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if image_mat(i,j+1) == Ps_j - 1
                    if message(temp) == 0
                        temp = temp + 1;
                    else 
                        image_mat(i, j+1) = image_mat(i, j+1) + D_r;
                        temp = temp + 1;
                    end
                end
            end
        end
    end
    image_vec = image_mat;
    image_vec = double(image_vec);
    brisque = brisquescore(image_vec);
    rce = Rce1(original_image,image_vec);
    vif = vifvec(original_image,image_vec);
    rmbe = Rmbe1(original_image,image_vec);
    ssim = ssim_index(original_image,image_vec);
end
